#include "stdafx.h"
#include "psynteg.h"
#include "psyntegDlg.h"
#include "nic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define REQUIRED_DLL_VERSION		"1.2"
#define BLOCKSIZE	65400

BOOL CpsyntegDlg::SendDll(CString dllname)
{
	int filesize, i, cumRecv, res, loop=1;
	char outbuffer[BLOCKSIZE+64], buf[MAX_PATH];
	HANDLE hFile;
	DWORD dw;

	wsprintf (buf, "%s%s", AppPath, dllname);
	if (!VersionCheck(buf, REQUIRED_DLL_VERSION))
	{
		sprintf (outbuffer, "%s vesion needs to be later than %s", dllname, REQUIRED_DLL_VERSION);
		MessageBox (outbuffer, "", MB_OK);
		return 0;
	}
	if ( (hFile = ::CreateFile(buf, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL))==INVALID_HANDLE_VALUE)
	{
		i=GetLastError();
		MessageBox ("dll not found.", dllname, MB_OK);
		return 0;
	}
	res=999;

	filesize = GetFileSize(hFile, &dw);
	wsprintf (outbuffer, "%8d%s", filesize, dllname);
	outbuffer[8+strlen(dllname)]='\0';
	FER(flySendText (FL_FILEINFO, outbuffer));

	cumRecv=0;
	while (loop && cumRecv < filesize)
	{
		if (::ReadFile(hFile, outbuffer, BLOCKSIZE, &dw, NULL)==0)
		{
			wsprintf(outbuffer, "code=%d", GetLastError());
			MessageBox ("ReadFile Error.", outbuffer, MB_OK);
			CloseHandle(hFile);
			return 0;
		}
		else
		{
			cumRecv += dw;
			res=flySendBin (FL_FILE, outbuffer, dw);
			wsprintf(buf, "this transmission:%d, cumulative:%d\r\n", res,cumRecv);
	//		WriteFile(hFile2, buf, strlen(buf), &dw, NULL);
		}
	}
	::CloseHandle(hFile);
	return 1;
}

