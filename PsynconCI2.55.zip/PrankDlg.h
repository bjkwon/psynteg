#pragma once

// CPrankDlg dialog

class CPrankDlg : public CDialog
{
	DECLARE_DYNAMIC(CPrankDlg)

public:
	CWnd* hPar;
	CString m_str_v1;
	CString m_str_v2;
	CString m_instruction;
	CPrankDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPrankDlg();

// Dialog Data
	enum { IDD = IDD_PRANK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
protected:
	DECLARE_MESSAGE_MAP()
public:
	bool m_random;
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};
