// Stringchain.h: interface for the CStringchain class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRINGCHAIN_H__6E8BBF1F_68A3_4DB8_9E57_119F7364FB3E__INCLUDED_)
#define AFX_STRINGCHAIN_H__6E8BBF1F_68A3_4DB8_9E57_119F7364FB3E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStringchain  
{
public:
	void GetCurrentDeck(CString const str, CString& nextStr);
	int FreeChain();
	int MakeChain(CString str);
	CString cmd;
	CStringchain *Next;
	CStringchain();
	virtual ~CStringchain();
};

#endif // !defined(AFX_STRINGCHAIN_H__6E8BBF1F_68A3_4DB8_9E57_119F7364FB3E__INCLUDED_)
