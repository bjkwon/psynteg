// Stringchain.cpp: implementation of the CStringchain class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "psynteg.h"
#include "Stringchain.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CStringchain::CStringchain()
{
	Next= NULL;
}

CStringchain::~CStringchain()
{

}

int CStringchain::MakeChain(CString str)
{ // from orginal string, it construct all the string chain.

	CString nextStr;
	CStringchain *temp;

	GetCurrentDeck(str, nextStr);
	if (nextStr!="")
	{
		temp = new CStringchain;
		temp->MakeChain(nextStr);
		Next = temp;
	}
	return 1;
}

int CStringchain::FreeChain()
{
	if (Next==NULL)
		return 0;
	if (Next->Next==NULL)
	{
		delete Next;
		return 1;
	}
	else
	{
		if (Next->FreeChain())
			delete Next;

		cmd="";
		Next = NULL;
		return 1;
	}
}

void CStringchain::GetCurrentDeck(CString const str, CString& nextStr)
{
	CString arg[2], buf1, buf2;
	int nItems;
	nItems = countDeliminators(str, "\r\n");
	arg[0]=buf1;
	arg[1]=buf2;

	if (nItems==0)
		return;
	else if (nItems==1)
	{
		cmd = str;
		nextStr = "";
	}
	else
	{
		str2array(arg, 2, str, "\r\n");
		cmd = arg[0];
		nextStr = str.Mid(str.Find(arg[0])+arg[0].GetLength());
	}
}
