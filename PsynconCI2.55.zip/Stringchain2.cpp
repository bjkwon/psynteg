#include "Stringchain.h"
#include "bjtools.h"

CStringchain::CStringchain()
{
	Next= NULL;
}

CStringchain::~CStringchain()
{

}

int CStringchain::MakeChain(CString str)
{ // from orginal string, it construct all the string chain.

	CString nextStr;
	CStringchain *temp;
	int res;

	GetCurrentDeck(str, nextStr);
	if (nextStr!="")
	{
		temp = new CStringchain;
		temp->MakeChain(nextStr);
		Next = temp;
	}
	return res;
}

int CStringchain::FreeChain()
{
	if (Next==NULL)
		return 0;
	if (Next->Next==NULL)
	{
		delete Next;
		return 1;
	}
	else
	{
		if (Next->FreeChain())
			delete Next;

		cmd="";
		Next = NULL;
		return 1;
	}
}

int CStringchain::CStringParse(CString *array, int nMax, const char *str, char *breaker)
{
	int i, nItems, maxLength;
	char **temp;
	maxLength = strlen(str)+1;
	nItems = countDeliminators(str, breaker);
	temp = new char*[nItems];
	for (i=0; i<nItems; i++)
		temp[i] = new char[maxLength];
	str2strarray(temp, nItems, str, breaker);
	for (i=0; i<nItems; i++)
		array[i] = temp[i];
	for (i=0; i<nItems; i++)
		delete[] temp[i];
	delete[] temp;
	return nItems;
}

void CStringchain::GetCurrentDeck(CString const str, CString& nextStr)
{
	CString *arg, buf1, buf2;
	int nItems;
	nItems = countDeliminators(str, "\r\n");
	arg[0]=bufl;
	arg[1]=buf2;

	if (nItems==0)
		return -1;
	else (nItems==1)
	{
		cmd = str;
		nextStr = NULL;
	}
	else
	{
		CStringParse(arg, 2, str, "\r\n");
		cmd = arg[0];
		nextStr = str.Mid(str.Find(arg[0])+arg[0].GetLength());
	}
	return (nItems>1);
}

