// PrankDlg.cpp : implementation file
//

#include "stdafx.h"
#include "psynteg.h"
#include "PrankDlg.h"


// CPrankDlg dialog

IMPLEMENT_DYNAMIC(CPrankDlg, CDialog)

CPrankDlg::CPrankDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPrankDlg::IDD, pParent)
	, m_str_v1(_T(""))
	, m_str_v2(_T(""))
	, m_instruction(_T(""))
	, m_random(false)
{
	hPar = pParent;
}

CPrankDlg::~CPrankDlg()
{
}

void CPrankDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_V1, m_str_v1);
	DDX_Text(pDX, IDC_V2, m_str_v2);
	DDX_Text(pDX, IDC_INST, m_instruction);
	//DDX_Check(pDX, IDC_RANDOM, ____);
}


BEGIN_MESSAGE_MAP(CPrankDlg, CDialog)
END_MESSAGE_MAP()


// CPrankDlg message handlers

LRESULT CPrankDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (message==WM_COMMAND)
	{
		if (wParam==IDCANCEL || wParam==IDOK)
		return NULL;
	}
	return CDialog::WindowProc(message, wParam, lParam);
}
