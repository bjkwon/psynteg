#include <windows.h>
#include <commctrl.h>  
#include <stdio.h>
#include "flyplus.h"
#include "resource.h"
#include "..\protocol.h"


#define BUTT1		923
#define BUTT2		924
#define BUTT3		925
#define BUTT4		926
#define BUTT5		927
#define ID_HMSG		928
#define ID_FEEDBACK	929
#define ID_HBEGIN		1928
#define ID_HMSG2		948
#define ID_COUNTER		9248
#define ID_CAP			1200
#define ID_SLIDERVAL	2000
#define ID_PLAY			2001
#define ID_DONE			2002
#define ID_NEED_MORE	2003
#define ID_SLIDER		2004
#define ID_EDIT			2005

#define WM__STOPPED		WM_APP+229


#define FDBCKTIMER	1000
#define BEGINDELAY  1001
#define PRESS_BEGIN  1002
#define PRESS_RESPONSE  1003

#define MAX_INTERVALS  5
#define STOPPED_BY_USER  1


#define AUTORESP  2000
