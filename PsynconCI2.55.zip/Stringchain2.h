#include "StdString.h"

class CStringchain  
{
public:
	void GetCurrentDeck(CString str, CString nextStr);
	int CStringParse(CString *array, int nMax, const char *str, char *breaker);
	int FreeChain();
	int MakeChain(CStdString str, char type);
	CStdString cmd;
	CStringchain *Next;
	CStringchain();
	virtual ~CStringchain();
};
